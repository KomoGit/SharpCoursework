﻿using AngerTravelTours.Models;

namespace AngerTravelTours.ViewModel
{
    public class VMGallery
    {
        public List<Gallery> Galleries { get; set; }
        public List<Partner> Partners { get; set; }
        public List<Feedback> Feedbacks { get; set; }
        public List<TourPackage> Packages { get; set; }
        public List<Blog> Blogs { get; set; }
    }
}
