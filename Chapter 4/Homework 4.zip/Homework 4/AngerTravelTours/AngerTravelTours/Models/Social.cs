﻿namespace AngerTravelTours.Models
{
    public class Social:BaseEntities
    {
        public string Icon { get; set; }
        public string Link { get; set; }
    }
}
