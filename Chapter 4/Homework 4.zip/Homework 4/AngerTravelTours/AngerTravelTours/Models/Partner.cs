﻿namespace AngerTravelTours.Models
{
    public class Partner:BaseEntities
    {
        public string Image { get; set; }
        public string Link { get; set; }
    }
}
