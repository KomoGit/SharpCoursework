﻿using System.ComponentModel.DataAnnotations;

namespace AngerTravelTours.Models
{
    public class BaseEntities
    {
        [Key]
        public int Id { get; set; }
    }
}
