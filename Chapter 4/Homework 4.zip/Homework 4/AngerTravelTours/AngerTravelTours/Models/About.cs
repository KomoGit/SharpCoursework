﻿using System.ComponentModel.DataAnnotations;

namespace AngerTravelTours.Models
{
    public class About:BaseEntities
    {
        public string Image { get; set; }
        public string  Desc { get; set; }
    }
}
