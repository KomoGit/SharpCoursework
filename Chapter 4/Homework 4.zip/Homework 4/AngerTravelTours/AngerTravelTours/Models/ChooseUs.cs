﻿namespace AngerTravelTours.Models
{
    public class ChooseUs:BaseEntities
    {
        public string Title { get; set; }
        public string Image { get; set; }
        public string VideoLink { get; set; }
        public string Desc { get; set; }
    }
}
