﻿namespace AngerTravelTours.Models
{
    public class Gallery:BaseEntities
    {
        public string Name { get; set; }
        public string Image { get; set; }
    }
}
