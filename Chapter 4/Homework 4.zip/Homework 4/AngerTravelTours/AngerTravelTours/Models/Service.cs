﻿namespace AngerTravelTours.Models
{
    public class Service:BaseEntities
    {
        public string Icon { get; set; }
        public string Title { get; set; }
        public string Desc { get; set; }
    }
}
