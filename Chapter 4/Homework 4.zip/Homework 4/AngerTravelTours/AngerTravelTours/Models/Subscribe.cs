﻿namespace AngerTravelTours.Models
{
    public class Subscribe:BaseEntities
    {
        public string Email { get; set; }
        public DateTime AddedDate { get; set; }
    }
}
