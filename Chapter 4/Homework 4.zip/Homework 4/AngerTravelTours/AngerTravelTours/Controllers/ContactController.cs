﻿using AngerTravelTours.Data;
using AngerTravelTours.ViewModel;
using Microsoft.AspNetCore.Mvc;

namespace AngerTravelTours.Controllers
{
    public class ContactController : Controller
    {
        private readonly AngerDbContext _context;

        public ContactController(AngerDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            VMGallery model = new()
            {
                Feedbacks = _context.Feedbacks.ToList(),
                Galleries = _context.Galleries.ToList(),
                Partners = _context.Partners.ToList(),
                Packages = _context.TourPackages.ToList(),
                Blogs = _context.Blogs.ToList(),
            };
            return View(model);
        }
    }
}
